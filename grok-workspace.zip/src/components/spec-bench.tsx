import { useEffect, useRef, useState } from "react";
import { PRESETS } from "@/lib/models/catalog";
import { matchHardware } from "@/lib/server/match";
import type { MatchResult, ModelTask, Specs } from "@/lib/models/types";
import { MatchResults } from "./match-results";
import { cn } from "@/lib/utils";

const TASKS: Array<{ id: ModelTask | "any"; label: string }> = [
  { id: "any", label: "anything" },
  { id: "chat", label: "chat" },
  { id: "code", label: "code" },
  { id: "reason", label: "reason" },
  { id: "vision", label: "vision" },
  { id: "image", label: "image" },
  { id: "agent", label: "agent" },
];

const PLACEHOLDER = `paste anything:

GPU: NVIDIA GeForce RTX 4070
Dedicated video memory: 12.0 GB
Installed physical memory: 32.0 GB
Processor: AMD Ryzen 7 5800X

or a screenshot of Task Manager / About This Mac / neofetch`;

async function fileToDataUrl(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const max = 1280;
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas");
  ctx.drawImage(bitmap, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", 0.72);
}

export function SpecBench() {
  const [text, setText] = useState("");
  const [task, setTask] = useState<ModelTask | "any">("any");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [shotName, setShotName] = useState<string | null>(null);
  const [shotUrl, setShotUrl] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (result) resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [result]);

  async function run(opts?: { preset?: Specs; image?: string }) {
    setBusy(true);
    setError(null);
    try {
      const res = await matchHardware({
        data: {
          text: opts?.preset ? undefined : text,
          imageDataUrl: opts?.image ?? shotUrl ?? undefined,
          prefer: task === "any" ? undefined : task,
          presetSpecs: opts?.preset,
        },
      });
      if ("error" in res) {
        setError(res.error);
        setResult(null);
      } else {
        setResult(res);
      }
    } catch {
      setError("Match failed. Try a shorter paste, or pick a preset rig.");
    } finally {
      setBusy(false);
    }
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("That is not an image.");
      return;
    }
    try {
      const url = await fileToDataUrl(file);
      setShotUrl(url);
      setShotName(file.name);
      await run({ image: url });
    } catch {
      setError("Could not read that screenshot.");
    }
  }

  return (
    <div>
      <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
        <div>
          <p className="text-2xs uppercase tracking-[0.28em] text-muted">step 1 · hardware</p>
          <h1 className="mt-3 text-2xl leading-tight sm:text-3xl">
            paste your specs.
            <br />
            get the models that fit.
          </h1>
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted">
            No signup. Copy dxdiag, neofetch, About This Mac, GPU-Z, or a screenshot. We read VRAM and
            RAM, then rank open-weight models you can actually run.
          </p>
        </div>
        <div className="text-xs leading-relaxed text-muted lg:pt-8">
          <div className="border border-line p-4">
            <div className="text-2xs uppercase tracking-widest text-fg">how to copy specs</div>
            <ul className="mt-3 space-y-2">
              <li>Windows — Win+R, type dxdiag, copy the text. Or screenshot Task Manager → Performance.</li>
              <li>macOS — Apple menu → About This Mac. Screenshot is enough.</li>
              <li>Linux — neofetch or inxi -F. Paste the lot.</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-8 flex flex-wrap gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => run({ preset: { ...p.specs, source: "preset" } })}
            className="min-h-11 border border-line px-3 py-2 text-xs text-muted hover:border-fg hover:text-fg"
          >
            {p.label}
            <span className="ml-2 text-dim"> {p.hint}</span>
          </button>
        ))}
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {TASKS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTask(t.id)}
            className={cn(
              "min-h-11 border px-3 py-2 text-xs uppercase tracking-widest",
              task === t.id
                ? "border-fg bg-fg text-bg"
                : "border-line text-muted hover:border-fg hover:text-fg",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <label className="mt-6 block">
        <span className="sr-only">Hardware specifications</span>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={8}
          placeholder={PLACEHOLDER}
          className="min-h-44 w-full resize-y border border-line bg-surface px-4 py-3 text-sm leading-relaxed text-fg placeholder:text-dim focus:border-fg focus:outline-none"
        />
      </label>

      <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <button
          type="button"
          disabled={busy}
          onClick={() => run()}
          className="min-h-12 bg-fg px-5 text-sm uppercase tracking-widest text-bg hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "matching…" : "match models"}
        </button>
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="min-h-12 border border-line px-5 text-sm uppercase tracking-widest text-fg hover:bg-surface"
        >
          {shotName ? `screenshot · ${shotName}` : "drop a screenshot"}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => onFile(e.target.files?.[0])}
        />
        {shotName ? (
          <button
            type="button"
            className="text-xs text-muted underline underline-offset-4"
            onClick={() => {
              setShotName(null);
              setShotUrl(null);
            }}
          >
            clear image
          </button>
        ) : null}
      </div>

      {error ? <p className="mt-4 text-sm text-fg">{error}</p> : null}

      {result ? (
        <div className="enter-up mt-10" ref={resultRef}>
          <MatchResults result={result} />
        </div>
      ) : null}
    </div>
  );
}
