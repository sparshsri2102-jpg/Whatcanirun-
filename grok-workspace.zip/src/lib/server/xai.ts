export async function grokJson<T>(args: {
  prompt: string;
  imageDataUrl?: string;
  maxTokens?: number;
}): Promise<{ ok: true; data: T } | { ok: false; error: string }> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available" };

  const content: Array<Record<string, unknown>> = [];
  if (args.imageDataUrl) {
    content.push({
      type: "image_url",
      image_url: { url: args.imageDataUrl },
    });
  }
  content.push({ type: "text", text: args.prompt });

  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      max_tokens: args.maxTokens ?? 500,
      temperature: 0,
      messages: [
        {
          role: "system",
          content:
            "You extract structured data. Reply with a single JSON object. No markdown, no commentary.",
        },
        { role: "user", content },
      ],
    }),
  });

  if (!res.ok) {
    return { ok: false, error: `xAI API error ${res.status}` };
  }

  const body = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const text = body.choices?.[0]?.message?.content ?? "";
  const json = extractJson(text);
  if (!json) return { ok: false, error: "Could not parse model output" };
  return { ok: true, data: json as T };
}

function extractJson(text: string): unknown | null {
  const trimmed = text.trim();
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fence?.[1]?.trim() ?? trimmed;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(candidate.slice(start, end + 1));
  } catch {
    return null;
  }
}
