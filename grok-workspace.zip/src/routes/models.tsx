import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteShell } from "@/components/site-shell";
import { MODELS } from "@/lib/models/catalog";
import type { ModelTask } from "@/lib/models/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/models")({ component: ModelsPage });

const FILTERS: Array<{ id: "all" | ModelTask; label: string }> = [
  { id: "all", label: "all" },
  { id: "chat", label: "chat" },
  { id: "code", label: "code" },
  { id: "reason", label: "reason" },
  { id: "vision", label: "vision" },
  { id: "image", label: "image" },
  { id: "audio", label: "audio" },
  { id: "agent", label: "agent" },
];

function ModelsPage() {
  const [q, setQ] = useState("");
  const [task, setTask] = useState<(typeof FILTERS)[number]["id"]>("all");
  const [vram, setVram] = useState<number>(0);

  const rows = useMemo(() => {
    return MODELS.filter((m) => {
      if (task !== "all" && !m.tasks.includes(task)) return false;
      if (vram && m.quants.every((x) => x.vramGb > vram)) return false;
      if (q) {
        const hay = `${m.name} ${m.org} ${m.summary} ${m.license}`.toLowerCase();
        if (!hay.includes(q.toLowerCase())) return false;
      }
      return true;
    }).sort((a, b) => b.quality - a.quality);
  }, [q, task, vram]);

  return (
    <SiteShell>
      <p className="text-2xs uppercase tracking-[0.28em] text-muted">catalog</p>
      <h1 className="mt-3 text-2xl sm:text-3xl">every model we match against</h1>
      <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
        Curated open-weight catalog with GGUF sizes. Live Hugging Face noise lives on drops. Filter by
        VRAM ceiling to see what a card can hold at Q4.
      </p>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="search name, org, license"
          className="min-h-12 flex-1 border border-line bg-surface px-3 text-sm focus:border-fg focus:outline-none"
        />
        <label className="flex min-h-12 items-center gap-3 border border-line bg-surface px-3 text-xs text-muted">
          max VRAM
          <select
            value={vram}
            onChange={(e) => setVram(Number(e.target.value))}
            className="bg-transparent text-fg focus:outline-none"
          >
            <option value={0}>any</option>
            <option value={8}>8 GB</option>
            <option value={12}>12 GB</option>
            <option value={16}>16 GB</option>
            <option value={24}>24 GB</option>
            <option value={32}>32 GB</option>
            <option value={64}>64 GB</option>
            <option value={128}>128 GB</option>
          </select>
        </label>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setTask(f.id)}
            className={cn(
              "min-h-11 border px-3 text-xs uppercase tracking-widest",
              task === f.id ? "border-fg bg-fg text-bg" : "border-line text-muted hover:text-fg",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-6 text-xs text-muted">{rows.length} models</div>
      <div className="mt-3 divide-y divide-line border border-line">
        {rows.map((m) => {
          const q4 = m.quants.find((x) => x.name === "Q4") ?? m.quants[0];
          return (
            <article key={m.id} className="grid gap-3 px-4 py-4 sm:grid-cols-[1.2fr_0.8fr] sm:items-start">
              <div>
                <div className="text-2xs uppercase tracking-widest text-muted">{m.org}</div>
                <h2 className="mt-1 text-base">{m.name}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted">{m.summary}</p>
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs">
                  <a href={m.hf} className="underline underline-offset-4" target="_blank" rel="noreferrer">
                    huggingface
                  </a>
                  {m.gguf ? (
                    <a href={m.gguf} className="underline underline-offset-4" target="_blank" rel="noreferrer">
                      GGUF
                    </a>
                  ) : null}
                  {m.run.ollama ? <code className="text-muted">{m.run.ollama}</code> : null}
                </div>
              </div>
              <dl className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <dt className="text-dim">params</dt>
                  <dd>{m.params}</dd>
                </div>
                <div>
                  <dt className="text-dim">license</dt>
                  <dd>{m.license}</dd>
                </div>
                <div>
                  <dt className="text-dim">Q4-ish</dt>
                  <dd className="tabular-nums">{q4 ? `${q4.vramGb} GB` : "—"}</dd>
                </div>
                <div>
                  <dt className="text-dim">context</dt>
                  <dd>{m.contextK ? `${m.contextK}k` : "n/a"}</dd>
                </div>
                <div className="col-span-2">
                  <dt className="text-dim">tasks</dt>
                  <dd>{m.tasks.join(" · ")}</dd>
                </div>
              </dl>
            </article>
          );
        })}
      </div>
    </SiteShell>
  );
}
