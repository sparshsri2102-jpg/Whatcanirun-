import { MODELS } from "./catalog";
import type { FitKind, MatchResult, Model, ModelFit, ModelTask, Quant, Specs } from "./types";

const TASK_LABEL: Record<ModelTask, string> = {
  chat: "chat",
  code: "code",
  reason: "reasoning",
  vision: "vision",
  image: "image gen",
  video: "video",
  audio: "audio",
  embed: "embeddings",
  agent: "agents",
};

function pools(specs: Specs) {
  const vram = Math.max(0, specs.vramGb) * Math.max(1, specs.gpuCount || 1);
  const ram = Math.max(0, specs.ramGb);
  if (specs.unified) {
    const usable = ram * 0.72;
    return { gpu: usable, hybrid: usable, cpu: usable };
  }
  return {
    gpu: vram * 0.9,
    hybrid: vram * 0.9 + ram * 0.5,
    cpu: ram * 0.62,
  };
}

function bestQuant(model: Model, specs: Specs): { quant: Quant; fit: FitKind; headroomGb: number } | null {
  const p = pools(specs);
  const ordered = [...model.quants].sort((a, b) => b.quality - a.quality);
  let cpu: { quant: Quant; headroomGb: number } | null = null;
  let hybrid: { quant: Quant; headroomGb: number } | null = null;

  for (const quant of ordered) {
    if (quant.vramGb <= p.gpu) {
      return { quant, fit: "gpu", headroomGb: p.gpu - quant.vramGb };
    }
    if (!hybrid && quant.vramGb <= p.hybrid) {
      hybrid = { quant, headroomGb: p.hybrid - quant.vramGb };
    }
    if (!cpu && quant.vramGb <= p.cpu) {
      cpu = { quant, headroomGb: p.cpu - quant.vramGb };
    }
  }

  if (hybrid) return { ...hybrid, fit: "hybrid" };
  if (cpu) return { ...cpu, fit: "cpu" };
  return null;
}

function speedHint(fit: FitKind, specs: Specs, model: Model): string {
  if (fit === "gpu") {
    if (specs.unified) return model.paramsB >= 20 ? "~12–25 tok/s unified" : "~25–50 tok/s unified";
    if (specs.vramGb >= 24) return model.paramsB >= 24 ? "~40–80 tok/s" : "~80–150 tok/s";
    if (specs.vramGb >= 12) return "~25–50 tok/s";
    return "~15–30 tok/s";
  }
  if (fit === "hybrid") return "partial offload · slower, still usable";
  return "CPU · expect single-digit tok/s";
}

function why(model: Model, fit: FitKind, quant: Quant, specs: Specs): string {
  const task = model.tasks.filter((t) => t !== "chat").slice(0, 2).map((t) => TASK_LABEL[t]).join(" + ");
  const where = fit === "gpu" ? "fully on GPU" : fit === "hybrid" ? "GPU + RAM offload" : "CPU RAM";
  const card = specs.unified ? `${specs.ramGb} GB unified` : `${specs.vramGb} GB VRAM`;
  return `${quant.name} is ${quant.vramGb} GB · ${where} on ${card}${task ? ` · ${task}` : ""}`;
}

function scoreFit(model: Model, fit: FitKind, quant: Quant, headroomGb: number, prefer?: ModelTask): number {
  let s = model.quality * 0.55 + quant.quality * 0.2;
  if (fit === "gpu") s += 40;
  else if (fit === "hybrid") s += 12;
  else s -= 8;
  // Prefer filling the card, not recommending a 3B to a 4090.
  if (fit === "gpu") {
    const used = quant.vramGb;
    s += Math.min(18, used * 0.35);
    if (headroomGb > 20 && model.paramsB < 8) s -= 12;
  }
  if (prefer && model.tasks.includes(prefer)) s += 10;
  if (model.license.toLowerCase().includes("apache") || model.license === "MIT") s += 2;
  const recency = Date.parse(`${model.released}-01`) || 0;
  s += Math.max(0, (recency - Date.parse("2024-01-01")) / (1000 * 60 * 60 * 24 * 40));
  return s;
}

export function matchModels(specs: Specs, prefer?: ModelTask): MatchResult {
  const fits: ModelFit[] = [];
  for (const model of MODELS) {
    const found = bestQuant(model, specs);
    if (!found) continue;
    const { quant, fit, headroomGb } = found;
    fits.push({
      model,
      quant,
      fit,
      headroomGb,
      score: scoreFit(model, fit, quant, headroomGb, prefer),
      why: why(model, fit, quant, specs),
      speed: speedHint(fit, specs, model),
    });
  }

  fits.sort((a, b) => b.score - a.score);

  const picks: ModelFit[] = [];
  const seenOrg = new Set<string>();
  const seenTaskKey = new Set<string>();
  for (const f of fits) {
    if (picks.length >= 4) break;
    const key = `${f.model.org}:${f.model.tasks[0]}`;
    if (seenOrg.has(f.model.org) && seenTaskKey.has(key) && picks.length < 3) continue;
    if (seenOrg.has(f.model.org) && picks.length >= 2) continue;
    picks.push(f);
    seenOrg.add(f.model.org);
    seenTaskKey.add(key);
  }
  if (picks.length < 3) {
    for (const f of fits) {
      if (picks.length >= 4) break;
      if (picks.some((p) => p.model.id === f.model.id)) continue;
      picks.push(f);
    }
  }

  const pickIds = new Set(picks.map((p) => p.model.id));
  const also = fits.filter((f) => !pickIds.has(f.model.id)).slice(0, 6);

  const gpuPicks = picks.filter((p) => p.fit === "gpu").length;
  const blurb = gpuPicks
    ? `${gpuPicks} of ${picks.length} run fully on this machine. Bigger weights exist — they just do not fit.`
    : picks.length
      ? "Nothing here sits fully in VRAM. These are the least-painful offload / CPU options."
      : "This machine is below the floor for current open-weight LLMs. Try a 3B Q4 on CPU, or add RAM.";

  return { specs, picks, also, blurb };
}

export { TASK_LABEL };
