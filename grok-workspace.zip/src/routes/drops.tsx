import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteShell } from "@/components/site-shell";
import { listDrops, type DropItem } from "@/lib/server/drops";

export const Route = createFileRoute("/drops")({ component: DropsPage });

function timeAgo(iso: string) {
  const ms = Date.now() - Date.parse(iso);
  if (!Number.isFinite(ms) || ms < 0) return "just now";
  const m = Math.floor(ms / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function DropsPage() {
  const [items, setItems] = useState<DropItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let n = 0;
    const load = () => {
      listDrops()
        .then((rows) => {
          setItems(rows);
          setError(null);
        })
        .catch(() => {
          if (!n) setError("Could not reach Hugging Face / GitHub right now.");
        });
      n += 1;
    };
    load();
    const id = window.setInterval(load, 90_000);
    return () => window.clearInterval(id);
  }, []);

  const hf = items?.filter((i) => i.source === "huggingface") ?? [];
  const gh = items?.filter((i) => i.source === "github") ?? [];

  return (
    <SiteShell>
      <p className="text-2xs uppercase tracking-[0.28em] text-muted">live feed</p>
      <h1 className="mt-3 text-2xl sm:text-3xl">open-weight drops</h1>
      <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
        Hugging Face text-generation + GGUF, filtered for known labs and anything with real likes. GitHub
        repos tagged gguf / llama.cpp / open-weight from the last weeks. Refreshes on its own.
      </p>
      {error ? <p className="mt-4 text-sm">{error}</p> : null}
      {!items ? <p className="mt-8 text-sm text-muted">listening…</p> : null}

      <div className="mt-8 grid gap-10 lg:grid-cols-2">
        <section>
          <h2 className="text-sm uppercase tracking-[0.22em] text-muted">huggingface</h2>
          <div className="mt-3 divide-y divide-line border border-line">
            {hf.map((d) => (
              <a
                key={d.id}
                href={d.url}
                target="_blank"
                rel="noreferrer"
                className="block px-4 py-3 hover:bg-surface"
              >
                <div className="flex items-baseline justify-between gap-3">
                  <div className="break-all text-sm">{d.name}</div>
                  <div className="shrink-0 text-2xs tabular-nums text-muted">{timeAgo(d.when)}</div>
                </div>
                <div className="mt-1 text-xs text-muted">
                  {d.likes} likes
                  {d.downloads ? ` · ${d.downloads.toLocaleString()} dl` : ""} · {d.summary}
                </div>
              </a>
            ))}
          </div>
        </section>
        <section>
          <h2 className="text-sm uppercase tracking-[0.22em] text-muted">github</h2>
          <div className="mt-3 divide-y divide-line border border-line">
            {gh.map((d) => (
              <a
                key={d.id}
                href={d.url}
                target="_blank"
                rel="noreferrer"
                className="block px-4 py-3 hover:bg-surface"
              >
                <div className="flex items-baseline justify-between gap-3">
                  <div className="break-all text-sm">{d.name}</div>
                  <div className="shrink-0 text-2xs tabular-nums text-muted">{timeAgo(d.when)}</div>
                </div>
                <div className="mt-1 text-xs text-muted">
                  {d.stars ?? d.likes} stars · {d.summary}
                </div>
              </a>
            ))}
          </div>
        </section>
      </div>
    </SiteShell>
  );
}
