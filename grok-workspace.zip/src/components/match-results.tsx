import { useState } from "react";
import type { MatchResult, ModelFit } from "@/lib/models/types";
import { cn } from "@/lib/utils";

function FitBadge({ fit }: { fit: ModelFit["fit"] }) {
  const label = fit === "gpu" ? "fits GPU" : fit === "hybrid" ? "offload" : "CPU";
  return (
    <span
      className={cn(
        "border px-2 py-0.5 text-2xs uppercase tracking-widest",
        fit === "gpu" ? "border-fg text-fg" : "border-line text-muted",
      )}
    >
      {label}
    </span>
  );
}

function CopyCmd({ cmd }: { cmd: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="text-2xs uppercase tracking-widest text-muted underline underline-offset-4 hover:text-fg"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(cmd);
          setDone(true);
          window.setTimeout(() => setDone(false), 1400);
        } catch {
          /* ignore */
        }
      }}
    >
      {done ? "copied" : "copy"}
    </button>
  );
}

function PickCard({ fit, rank }: { fit: ModelFit; rank: number }) {
  const m = fit.model;
  const cmd = m.run.ollama || m.run.llamacpp || "";
  return (
    <article className="border border-line bg-surface p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="text-2xs tabular-nums text-muted">
            {String(rank).padStart(2, "0")} · {m.org}
          </div>
          <h3 className="mt-1 text-lg">{m.name}</h3>
        </div>
        <div className="shrink-0">
          <FitBadge fit={fit.fit} />
        </div>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-muted">{m.summary}</p>
      <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-xs sm:grid-cols-4">
        <div>
          <dt className="text-dim">quant</dt>
          <dd className="mt-0.5">
            {fit.quant.name} · {fit.quant.vramGb} GB
          </dd>
        </div>
        <div>
          <dt className="text-dim">params</dt>
          <dd className="mt-0.5">{m.params}</dd>
        </div>
        <div>
          <dt className="text-dim">license</dt>
          <dd className="mt-0.5">{m.license}</dd>
        </div>
        <div>
          <dt className="text-dim">speed</dt>
          <dd className="mt-0.5">{fit.speed}</dd>
        </div>
      </dl>
      <p className="mt-3 text-xs text-muted">{fit.why}</p>
      {cmd ? (
        <div className="mt-4 flex items-start justify-between gap-3 border border-line bg-bg px-3 py-2">
          <code className="break-all text-xs">{cmd}</code>
          <CopyCmd cmd={cmd} />
        </div>
      ) : null}
      <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs">
        <a href={m.hf} target="_blank" rel="noreferrer" className="underline underline-offset-4">
          huggingface
        </a>
        {m.gguf ? (
          <a href={m.gguf} target="_blank" rel="noreferrer" className="underline underline-offset-4">
            GGUF download
          </a>
        ) : null}
        {m.run.lmstudio ? <span className="text-muted">{m.run.lmstudio}</span> : null}
      </div>
    </article>
  );
}

export function MatchResults({ result }: { result: MatchResult }) {
  const s = result.specs;
  return (
    <section>
      <div className="border border-line p-4 sm:p-5">
        <div className="text-2xs uppercase tracking-[0.28em] text-muted">your rig</div>
        <div className="mt-3 grid gap-3 text-sm sm:grid-cols-4">
          <div>
            <div className="text-dim">gpu</div>
            <div className="mt-1">{s.gpu}</div>
          </div>
          <div>
            <div className="text-dim">{s.unified ? "unified" : "vram"}</div>
            <div className="mt-1 tabular-nums">{s.unified ? `${s.ramGb} GB` : `${s.vramGb} GB`}</div>
          </div>
          <div>
            <div className="text-dim">system ram</div>
            <div className="mt-1 tabular-nums">{s.ramGb} GB</div>
          </div>
          <div>
            <div className="text-dim">os / cpu</div>
            <div className="mt-1">
              {s.os} · {s.cpu}
            </div>
          </div>
        </div>
        <p className="mt-4 text-sm text-muted">{result.blurb}</p>
      </div>

      <h2 className="mt-8 text-sm uppercase tracking-[0.22em] text-muted">top fits</h2>
      <div className="mt-3 grid gap-4">
        {result.picks.map((p, i) => (
          <PickCard key={p.model.id} fit={p} rank={i + 1} />
        ))}
      </div>

      {result.also.length ? (
        <>
          <h2 className="mt-10 text-sm uppercase tracking-[0.22em] text-muted">also runnable</h2>
          <div className="mt-3 divide-y divide-line border border-line">
            {result.also.map((p) => (
              <div
                key={p.model.id}
                className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <div className="text-sm">
                    {p.model.name}{" "}
                    <span className="text-muted">
                      · {p.quant.name} {p.quant.vramGb} GB
                    </span>
                  </div>
                  <div className="text-xs text-muted">{p.model.summary}</div>
                </div>
                <div className="flex shrink-0 items-center gap-3 text-xs">
                  <FitBadge fit={p.fit} />
                  <a href={p.model.hf} target="_blank" rel="noreferrer" className="underline underline-offset-4">
                    get
                  </a>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : null}
    </section>
  );
}
